def main():
    print('Fake from rb2301_tutorial.')


if __name__ == '__main__':
    main()
